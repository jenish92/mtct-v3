<?php
    $root = getenv("DOCUMENT_ROOT");
    require_once("$root/lib/connection-variables.php");
    require_once("$root/lib/db-connections.php");
    require_once("$root/lib/master.php");
    $mtct = new mtct();
    //include("iheader.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-P6K4GHW');</script>
<!-- End Google Tag Manager -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Online Donation - Mother Teresa Charitable Trust</title>

    <!-- Favicon -->
    <link rel="icon" href="external/images/favicon.ico" type="image/x-icon" />
    <!-- Bootstrap CSS -->
    <link href="<?php $root; ?>/external/css/bootstrap.min.css" rel="stylesheet">
	
    <!-- Animate CSS -->
    <link href="<?php $root; ?>/external/vendors/animate/animate.css" rel="stylesheet">
    <!-- Icon CSS-->
	<link rel="stylesheet" href="<?php $root; ?>/external/vendors/font-awesome/css/font-awesome.min.css">
    <!-- Camera Slider -->
    <link rel="stylesheet" href="<?php $root; ?>/external/vendors/camera-slider/camera.css">
    <!-- Owlcarousel CSS-->
	<link rel="stylesheet" type="text/css" href="<?php $root; ?>/external/vendors/owl_carousel/owl.carousel.css" media="all">

    <!--Theme Styles CSS-->
	

    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="external/js/html5shiv.min.js"></script>
    <script src="external/js/respond.min.js"></script>
    <![endif]-->
	
	<!------------------FROM SAME TEMPLATE !------------------!->
	
	<!-- core CSS -->
   
    <link href="<?php $root; ?>/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php $root; ?>/css/animate.min.css" rel="stylesheet">
    <link href="<?php $root; ?>/css/prettyPhoto.css" rel="stylesheet">
    <link href="<?php $root; ?>/css/main.css" rel="stylesheet">
    <link href="<?php $root; ?>/css/responsive.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?php $root; ?>/external/css/style.css" media="all" />

    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
	
	 <link rel="shortcut icon" href="images/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
	

<style type="text/css">
	
	.mtct-container{
	    //background-color:#f2f2f2;
	}
	.mtct-federal-payment{
	    -webkit-box-shadow: 0px 2px 12px 1px rgba(0,0,0,0.18);
-moz-box-shadow: 0px 2px 12px 1px rgba(0,0,0,0.18);
box-shadow: 0px 2px 12px 1px rgba(0,0,0,0.18);
	  /*box-shadow: 0 2px 4px 0 rgba(0,0,0,0.18);*/
	    background-color:#ffffff;
	}
	
	
	
	
	h1,h2{
	color: #0d2366;	
	}
	
	h1{
	    padding:2%;
	}
	
	.mtct-payment-left-side{
	padding: 24px;	
	}
	.mtct-payment-name{
	font-weight: bold;
    line-height: 28px;
    max-width: 80%;
    display: inline-block;
    vertical-align: middle;
	padding-left: 16px;
	font-size: 18px;
	color: #0d2366;
	text-align: left;
	}
	.mtct-payment-logo{	
	max-width:100%;
	text-align: center;
    position: relative;
    border-radius: 3px;
    box-shadow: 0 2px 4px 0 rgba(0,0,0,0.18);
    background: #fff;
    padding: 8px;
    margin-bottom:2%;
	}
	
	.mtct-payment-tax-details h3{
	font-size: 1.17em;
    line-height: 24px;
    font-weight: bold;
    margin-bottom: 4px;
    color: #0d2366;
	text-align: justify;
	
	}
	
	.mtct-payment-right-side{
	padding: 0 24px;	
	}
	.mtct-payment-right-side button
	{
	position: relative;
    width: 180px;
    min-height: 56px;
    font-size: 16px;
    font-weight: bold;
    line-height: 20px;
    border-radius: 0;
    text-align: center;
	}
	
	label{
		color: #0d2366;
	}
	.input-group-addon{
		color: #ffffff;
		background-color: #1b68e3;
		border-color: #1b68e3;
	}
	
	.form-group{
		margin: 3% 0%;
	}
	
	
	input[type="text"],
	input[type="number"],
	input[type="email"],
	input[type="date"],
	 .form-control{
	height: 40px;
	border: 1px solid #CCCCCC !important;
	box-sizing: border-box;
  	-moz-box-sizing: border-box;
  	-webkit-box-sizing: border-box;
	}
	
	.textarea{
		height: 60px !important;
	}
	
	
	input[type="text"]:focus,
	input[type="number"]:focus,
	input[type="email"]:focus,
	input[type="date"]:focus,
	.form-control:focus {
  background: transparent;
  border: 1px solid #528FF0;
  -webkit-box-shadow: none;
  box-shadow: none;
  border-radius: 0;
}

input[type="text"]:focus,
select.form-control:focus {
  -webkit-box-shadow: none;
  box-shadow: none;
}

.required {
  color: red;
}
</style>
</head>



    <section class="mtct-container ng-scope" ng-app="mtct" ng-controller="mtctDonate" ng-init="init()" style="padding: 0px 0;">
        <div class="mtct-federal-payment">
            
                <div style="margin-left: 208px;">
                <h2 style="text-decoration-line: underline;">Donor Details</h2>
 </div><hr>
            
    <div class="row">
    
    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 mtct-payment-right-side">
    	    
        	<form action="<?php $root; ?>/pay_u/test.php" method="post" id="donateForm" name="donateForm" target="_parent" novalidate>
           
           
           <div class="row">      
	
    <div class="form-group has-feedback col-md-6 col-12 col-sm-12 col-lg-6">
       	<label for="Donator Name">First Name<span class="required">*</span></label>
        	<div class="input-group ">
            	<span class="input-group-addon"><i class="fa fa-user"></i></span>
            	<input type="text" name="first_name" class="form-control" required="required" ng-model="first_name" ng-minlength="3" ng-maxlength="50" ng-pattern="/^[A-Za-z ]{3,50}$/">
            </div>
            <span style="color:red;" class="name-error" ng-show="donateForm.first_name.$dirty && donateForm.first_name.$error.required">Please Enter Your Name</span>
    		<span style="color:red" class="name-error" ng-show="donateForm.first_name.$error.pattern">Please Enter Your Valid Name</span>
    </div>
    
    <div class="form-group has-feedback col-md-6 col-12 col-sm-12 col-lg-6">
       	<label for="Donator Name">Last Name<span class="required">*</span></label>
        	<div class="input-group ">
            	<span class="input-group-addon"><i class="fa fa-user"></i></span>
            	<input type="text" name="last_name" class="form-control" required="required" ng-model="last_name" ng-minlength="1" ng-maxlength="50" ng-pattern="/^[A-Za-z ]{1,50}$/">
            </div>
            <span style="color:red;" class="name-error" ng-show="donateForm.last_name.$dirty && donateForm.last_name.$error.required">Please Enter Your Name</span>
    		<span style="color:red" class="name-error" ng-show="donateForm.last_name.$error.pattern">Please Enter Your Valid Name</span>
    </div>
        
                                                        
	
	
    </div>
           
           
    <div class="row">
        
        <div class="form-group has-feedback col-md-6 col-12 col-sm-12 col-lg-6">
   		<label for="Donator Email">Email<span class="required">*</span></label>
    		<div class="input-group ">
        	<span class="input-group-addon"><i class="fa fa-at"></i></span>
        	<input class="form-control" type="text" id="email" name="user_email" ng-blur="mailCheck(user_email,'S','availability','donateForm','user_email')" ng-model="user_email" noncapitalize required />
    		</div>
    		<div style="color: red" id="emailError">{{ availability }}</div>
	</div>
	
    	<div class="form-group has-feedback col-md-6 col-12 col-sm-12 col-lg-6">
       	<label for="Donator Name">Phone/Mobile<span class="required">*</span></label>
        	<div class="input-group ">
            	<span class="input-group-addon"><i class="fa fa-phone"></i></span>
            	<input type="text" name="user_mobile" class="form-control" required="required" ng-model="user_mobile" ng-minlength="stMin" ng-maxlength="stMax">
            </div>
            <span style="color:red;" class="mobile-error" ng-show="(donateForm.user_mobile.$error.number || donateForm.user_mobile.$error.required) && donateForm.user_mobile.$dirty">Please Enter Your Mobile Number</span>
    	<span style="color:red;" class="mobile-error" ng-show="donateForm.user_mobile.$error.minlength ||
                           donateForm.user_mobile.$error.maxlength">Please Enter Your Valid Mobile Number</span>
    </div>
    
    
    
    
    
    
    </div>       
           
           
           
      <div class="row">
          
          
    
      	 <div class="form-group has-feedback col-md-12 col-12 col-sm-12 col-lg-12">
    <label for="Donator Name">Address<span class="required">*</span></label>
		<div class="input-group ">
        <span class="input-group-addon"><i class="fa fa-map-marker"></i></span>
        <textarea name="user_address" ng-model="user_address" class="form-control" required>
			</textarea>
		</div>
		<span style="color:red;" class="country-error" ng-show="donateForm.user_address.$dirty && donateForm.user_address.$error.required">Please Enter Your Address</span>
	</div>    

      </div>     
           
           
      <div class="row">
      	    
      <div class="form-group has-feedback col-md-6 col-12 col-sm-12 col-lg-6">
      	    <label for="Donator Name">City<span class="required">*</span></label>
        	<div class="input-group ">
            	<span class="input-group-addon"><i class="fa fa-flag"></i></span>
            	<input type="text" name="user_city" class="form-control" required="required" ng-model="user_city" ng-minlength="2" ng-maxlength="50" ng-pattern="/^[A-Za-z ]{2,50}$/">
            </div>
            <span style="color:red;" class="name-error" ng-show="donateForm.user_city.$dirty && donateForm.user_city.$error.required">Please Enter Your City Name</span>
    		<span style="color:red" class="name-error" ng-show="donateForm.user_city.$error.pattern">Invalid. Ex : Chennai</span>
    </div>
    
    <div class="form-group has-feedback col-md-6 col-12 col-sm-12 col-lg-6">
      	    <label for="Donator Name">State<span class="required">*</span></label>
        	<div class="input-group ">
            	<span class="input-group-addon"><i class="fa fa-flag"></i></span>
            	<input type="text" name="user_state" class="form-control" required="required" ng-model="user_state" ng-minlength="2" ng-maxlength="50" ng-pattern="/^[A-Za-z ]{2,50}$/">
            </div>
            <span style="color:red;" class="name-error" ng-show="donateForm.user_state.$dirty && donateForm.user_state.$error.required">Please Enter Your State Name</span>
    		<span style="color:red" class="name-error" ng-show="donateForm.user_state.$error.pattern">Invalid. Ex : California</span>
    </div>
    
    </div>
    
    
    
    <div class="row">
      	    
      <div class="form-group has-feedback col-md-6 col-12 col-sm-12 col-lg-6">
      	    <label for="Donator Name">Country<span class="required">*</span></label>
        	<div class="input-group ">
            	<span class="input-group-addon"><i class="fa fa-flag"></i></span>
            	<select name="user_country" ng-model="user_country" ng-init="user_country = 'India'" class="form-control" required ng-change="setCurrency()">
        
        <option value="">Please Select</option>
        <?php
            foreach($mtct->currencyCodeList() as $key => $value){
                echo "<option value='$key'>$key</option>";
            }
            ?>
                
        </select>
            </div>
            <span style="color:red;" class="name-error" ng-show="donateForm.user_country.$dirty && donateForm.user_country.$error.required">Please Enter Your Country Name</span>
    		<span style="color:red" class="name-error" ng-show="donateForm.user_country.$error.pattern">Invalid. Ex : United States</span>
    </div>
    
    <div class="form-group has-feedback col-md-6 col-12 col-sm-12 col-lg-6">
      	    <label for="Donator Name">Zip Code<span class="required">*</span></label>
        	<div class="input-group ">
            	<span class="input-group-addon"><i class="fa fa-flag"></i></span>
            	<input type="text" name="user_zip" class="form-control" required="required" ng-model="user_zip" ng-minlength="2" ng-maxlength="50" ng-pattern="/^[0-9]{4,8}$/">
            </div>
            <span style="color:red;" class="name-error" ng-show="donateForm.user_zip.$dirty && donateForm.user_zip.$error.required">Please Enter Your City Name</span>
    		<span style="color:red" class="name-error" ng-show="donateForm.user_zip.$error.pattern">Invalid. Ex : Chennai</span>
    </div>
    
    </div>
    
      <div class="row">
      
      	    <div class="form-group has-feedback col-md-6 col-12 col-sm-12 col-lg-6">
      	    <label for="Donator Name">Date of Birth</label>
          
          <!-- Datepicker as text field -->         
          <div class="input-group date" data-date-format="dd.mm.yyyy">
            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
            <input type="date" name="user_dob" class="form-control" ng-model="user_dob">
            
          </div>
          
            
    </div>
      
<div class="form-group has-feedback col-md-6 col-12 col-sm-12 col-lg-6">
        	<label for="Donator Name">Supporting Towards<span class="required">*</span></label>
		<div class="input-group ">
        <span class="input-group-addon"><i class="fa fa-handshake-o"></i></span>
        <select name="user_donate" ng-model="user_donate" ng-init="stateChnaged('24')" class="form-control" required>
        
        <option value="">Please Select</option>
        <?php
            foreach($mtct->supportTowardsList() as $key => $value){
                $setVal = $key."|".$value;
                echo "<option value='$setVal'>$value</option>";
            }
            ?>
                
        </select>
		</div>
		<span style="color:red;" class="country-error" ng-show="donateForm.user_donate.$dirty && donateForm.user_donate.$error.required">Please Choose Anyone from the above category</span>
	</div> 
      </div>     
           
        <div class="row">
        	
       <div class="form-group has-feedback col-md-6 col-12 col-sm-12 col-lg-6">
        	<label for="Donator Name">Currency<span class="required">*</span></label>
		<div class="input-group ">
        <span class="input-group-addon"><i class="fa fa-handshake-o"></i></span>
        <select name="user_currency" ng-model="user_currency" ng-init="user_currency = 'INR'" class="form-control" required>
        
        <option value="">Please Select</option>
        <?php
            foreach($mtct->currencyCodeList() as $key => $value){
                $setVal = explode("-",$value);
                echo "<option value='$setVal[0]'>$value</option>";
            }
            ?>
                
        </select>
		</div>
		<span style="color:red;" class="country-error" ng-show="donateForm.user_currency.$dirty && donateForm.user_currency.$error.required">Please Choose Anyone from the above currency</span>
	</div> 
       
       <div class="form-group has-feedback col-md-6 col-12 col-sm-12 col-lg-6">
       	<label for="Donator Name">Amount<span class="required">*</span></label>
        	<div class="input-group ">
            	<span class="input-group-addon"><i class="fa fa-money"></i></span>
            	<input type="number" name="user_amount" class="form-control" required="required" ng-model="user_amount" ng-change="currencyConverter()">
            </div>
            <span style="color:red;" class="mobile-error" ng-show="(donateForm.user_amount.$error.number || donateForm.user_amount.$error.required) && donateForm.user_amount.$dirty">Please Enter the Valid Amount</span>
    	
    </div>
       
        </div>   
           
        <div class="row">
			<div class="form-group has-feedback col-md-6 col-12 col-sm-12 col-lg-6 ">
			    
			    <label ng-if="inr">{{user_currency +" "+ user_amount + " = " + "INR " + inr}}</label>
        	<div class="input-group ">
            	
            	<input type="hidden" hidden readonly name="user_inr" class="form-control" ng-model="user_inr" ng-value="inr">
            </div>
			    
			</div>
    <div class="form-group has-feedback col-md-6 col-12 col-sm-12 col-lg-6 ">
    	<center><button type="submit" name="donate_now" ng-disabled="donateForm.$invalid"  class="btn btn-primary">Donate Now</button></center>
    </div>
    
    </div>   
           
           
            
            </form>
            
        </div>
		<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 mtct-payment-left-side">
      <center>
          <img src="https://www.motherteresacharities.org/external/images/logoM.png"  class="mtct-payment-logo">

       </center>
       
       
        <center><img src="https://www.motherteresacharities.org/external/images/motherteresa.png" alt="Mother Terasa" >
        <div style="height: 24px;"></div>
        
        <div class="mtct-payment-tax-details">
        <div style="border:1px solid #0d2366;padding:2%;margin:0% 5%">
        <h3>Donations are excempted u/s.80G of the Income Tax Act, 1961. vide order No. DIT (E) No. 2(16) / 98 - 99 dt. 01.05.2009. PAN No : AABTM0430B</h3>
        </div>
        <div style="height:20px"></div>
        <h3 style="text-decoration:underline">Contact Us:</h3>
			<h3><span class="fa fa-envelope"></span>&nbsp;&nbsp;mtct1997@gmail.com</h3>
			<h3><span class="fa fa-envelope"></span>&nbsp;&nbsp;mtct1997@yahoo.co.in</h3>
			<h3><span class="fa fa-phone"></span>&nbsp;&nbsp;+914423743883,23742699 +918939300227</h3>
			<h3><span class="fa fa-globe"></span>&nbsp;&nbsp;<a href="http://mtct.info/">www.mtct.info</a></h3>
			<h3><span class="fa fa-globe"></span>&nbsp;&nbsp;<a href="http://www.motherteresacharities.org">www.motherteresacharities.org</a></h3>
 
        </div>
        </center>
    </div>
    </div>
    </div>
    </section>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.7.8/angular.js"></script>
<script type="text/javascript">
	
	
var admin = angular.module("mtct",[]);
  
  admin.controller("mtctDonate",function($scope,$http){
	  
	 $scope.stMin = 5;
	 $scope.stMax = 15;
	 var patt=/^[\w-]+(\.[\w-]+)*@([a-z0-9-]+(\.[a-z0-9-]+)*?\.[a-z]{2,6}|(\d{1,3}\.){3}\d{1,3})(:\d{4})?$/;
	 
	 
	 $scope.user_currency = "INR";
	 $scope.todays_rate = {};
	 $scope.inr = 0;
	 
	 $scope.init = () => {
	     console.log($scope.user_currency);
	     
	     const api_key = "44fa7577f77d875e0c830eb3";
	     
	     let old_url = "https://open.er-api.com/v6/latest/";
	     
	     let latest_url = "https://v6.exchangerate-api.com/v6/"+api_key+"/latest/";
	     
	     if($scope.user_currency != ""){
                    $http({
                      method: 'GET',
                      url: latest_url+$scope.user_currency,
                    }).then(function successCallback(response) {
                        console.log(response);
                        if(response.status == 200 ){
                            $scope.todays_rate = response.data.conversion_rates;
                            
                        }
                        else{
                            $scope.inr = "";
                        }
                      }, function errorCallback(response) {
                        console.log(response);
                        $scope.inr = "";
                      });
                }
                else{
                    console.log("Currency is mandatory");
                }
	     
	 }
	 
	 $scope.setCurrency = () => {
	      console.log($scope.user_country);
	     $http({
                      method: 'GET',
                      url: "currencyList.php?country="+$scope.user_country,
                    }).then(function successCallback(response) {
                        console.log(response);
                        if(response.status == 200 ){
                            $scope.getCurrency1 = response.data.split("-");
                            $scope.user_currency = $scope.getCurrency1[0];
                           
                        }
                        else{
                            $scope.user_currency = "INR";
                        }
                      }, function errorCallback(response) {
                        console.log(response);
                        $scope.user_currency = "INR";
                      });
	 }
	 
	 $scope.currencyConverter = () => {
	     console.log($scope.user_currency);
	     console.log($scope.todays_rate);
	     if($scope.user_currency != ""){
	        $scope.user_selected_currency_amount = $scope.todays_rate[$scope.user_currency];
	        $scope.inr = ($scope.user_amount * (1/$scope.user_selected_currency_amount)).toFixed(2);
	    }
	    else{
	        $scope.inr = 0;
	    }
	 }
	 
	 
	 
	 
	 $scope.mailCheck = function (pg_mail,proc,response_msg,formName,fiedName) {
	if(!pg_mail){
		$scope[response_msg]="Please Fillup the Field";
		$scope[formName][fiedName].$setValidity(fiedName, false);
	}
	
	else if(pg_mail.match(patt)) {
	
		  $scope[formName][fiedName].$setValidity(fiedName, true);
		  $scope[response_msg]="";
		  
	}
	
	else {
		
		$scope[response_msg]="Invalid Email";
		$scope[formName][fiedName].$setValidity(fiedName, false);
	}
        };	

  });
	
	
	</script>
